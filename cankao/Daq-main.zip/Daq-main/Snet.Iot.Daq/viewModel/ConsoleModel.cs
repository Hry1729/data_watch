using CommunityToolkit.Mvvm.Input;
using MaterialDesignThemes.Wpf;
using ScottPlot.WPF;
using Snet.Core.handler;
using Snet.Iot.Daq.chart;
using Snet.Iot.Daq.Core.data;
using Snet.Iot.Daq.Core.handler;
using Snet.Iot.Daq.Core.@interface;
using Snet.Iot.Daq.Core.mqtt.service;
using Snet.Iot.Daq.Core.mvvm;
using Snet.Iot.Daq.Core.opc.ua.service;
using Snet.Iot.Daq.data;
using Snet.Iot.Daq.utility;
using Snet.Iot.Daq.view;
using Snet.Log;
using Snet.Model.data;
using Snet.Utility;
using Snet.Windows.Controls.handler;
using Snet.Windows.Controls.message;
using System.Collections.ObjectModel;
using System.IO;
using static Snet.Iot.Daq.utility.SystemMonitoring;

namespace Snet.Iot.Daq.viewModel
{
    /// <summary>
    /// ����̨��ͼģ�ͣ�����ϵͳ�����Ϣ��ʾ��OPC UA/MQTT ����˹�������־����Լ��ɼ��豸����״̬���ۺϹ�����
    /// </summary>
    public class ConsoleModel : BindNotify
    {
        #region ���캯��
        /// <summary>
        /// ���캯��
        /// </summary>
        public ConsoleModel()
        {
            _ = InitAsync();
        }
        #endregion

        #region �����Ϣ

        private static readonly System.Windows.Media.SolidColorBrush s_cpuBrush = CreateFrozenBrush("#4CAF50");
        private static readonly System.Windows.Media.SolidColorBrush s_gpuBrush = CreateFrozenBrush("#F44336");
        private static readonly System.Windows.Media.SolidColorBrush s_ramBrush = CreateFrozenBrush("#2196F3");

        private static System.Windows.Media.SolidColorBrush CreateFrozenBrush(string hex)
        {
            var brush = (System.Windows.Media.SolidColorBrush)new System.Windows.Media.BrushConverter().ConvertFromString(hex);
            brush.Freeze();
            return brush;
        }
        public double Cpu
        {
            get => GetProperty(() => Cpu);
            set => SetProperty(() => Cpu, value);
        }
        public System.Windows.Media.Brush Cpu_Foreground
        {
            get => cpu_Foreground;
            set => SetProperty(ref cpu_Foreground, value);
        }
        private System.Windows.Media.Brush cpu_Foreground = s_cpuBrush;

        public double Gpu
        {
            get => GetProperty(() => Gpu);
            set => SetProperty(() => Gpu, value);
        }
        public System.Windows.Media.Brush Gpu_Foreground
        {
            get => gpu_Foreground;
            set => SetProperty(ref gpu_Foreground, value);
        }
        private System.Windows.Media.Brush gpu_Foreground = s_gpuBrush;

        public double RAM
        {
            get => GetProperty(() => RAM);
            set => SetProperty(() => RAM, value);
        }
        public System.Windows.Media.Brush RAM_Foreground
        {
            get => ram_Foreground;
            set => SetProperty(ref ram_Foreground, value);
        }
        private System.Windows.Media.Brush ram_Foreground = s_ramBrush;

        /// <summary>
        /// ����ϵͳ���ֵ
        /// </summary>
        private async Task UpdateSystemMonitoringValueAsync(CancellationToken token = default)
        {
            try
            {
                await Task.Run(async () =>
                {
                    // ��ѭ��������ֵ䣬����ÿ�ε������� GC ѹ��
                    Dictionary<string, double> values = new Dictionary<string, double>(4);

                    using var timer = new PeriodicTimer(TimeSpan.FromMilliseconds(_interval));
                    while (await timer.WaitForNextTickAsync(token))
                    {
                        HardwareData hardwareData = systemMonitoring.GetInfo();

                        foreach (var iteminfolist in hardwareData.Info)
                        {
                            if (iteminfolist.Key.Equals("�ڴ�"))
                            {
                                foreach (var item in iteminfolist.Values)
                                {
                                    if (double.TryParse(item.Value, System.Globalization.CultureInfo.InvariantCulture, out double value)
                                        && item.Key.Equals("����,Memory") && value > 0)
                                    {
                                        values["RAM"] = value;
                                    }
                                }
                            }
                            if (iteminfolist.Key.Equals("Ӣΰ���Կ�") || iteminfolist.Key.Equals("Ӣ�ض��Կ�") || iteminfolist.Key.Equals("AMD�Կ�"))
                            {
                                foreach (var item in iteminfolist.Values)
                                {
                                    if (double.TryParse(item.Value, System.Globalization.CultureInfo.InvariantCulture, out double value)
                                        && item.Key.Equals("����,GPU Core") && value > 0)
                                    {
                                        values["Gpu"] = value;
                                    }
                                }
                            }
                            if (iteminfolist.Key.Equals("������"))
                            {
                                foreach (var item in iteminfolist.Values)
                                {
                                    if (double.TryParse(item.Value, System.Globalization.CultureInfo.InvariantCulture, out double value)
                                        && item.Key.Equals("����,CPU Total") && value > 0)
                                    {
                                        values["Cpu"] = value;
                                    }
                                }
                            }
                        }
                        if (values.Count == 3)
                        {
                            foreach (var item in values)
                            {
                                double value = Math.Round(item.Value, 2);
                                UpdateLineSeriesData(item.Key, value);

                                switch (item.Key)
                                {
                                    case "Cpu":
                                        Cpu = value;
                                        break;
                                    case "Gpu":
                                        Gpu = value;
                                        break;
                                    case "RAM":
                                        RAM = value;
                                        break;
                                }
                            }
                        }
                    }
                }, token).ConfigureAwait(false);
            }
            catch (TaskCanceledException) { }
            catch (OperationCanceledException) { }
            catch (Exception ex) { await uiMessage.ShowAsync(ex.Message); }
        }

        /// <summary>
        /// ����ָ�����Ƶ�ͼ���������ݣ���������ֵ���͵�ͼ���������ʵʱ���ơ�
        /// </summary>
        /// <param name="name">�������ƣ��� "Cpu"��"Gpu"��"RAM"��</param>
        /// <param name="value">������ֵ</param>
        private void UpdateLineSeriesData(string name, double value)
        {
            chartOperate.Update(name, value);
        }
        #endregion

        #region ����
        /// <summary>
        /// ui��Ϣ������
        /// </summary>
        private UiMessageHandler uiMessage = UiMessageHandler.Instance("Info");

        /// <summary>
        /// ͼ������
        /// </summary>
        private ChartOperate chartOperate;

        /// <summary>
        /// ϵͳ��Ϣ���
        /// </summary>
        private SystemMonitoring systemMonitoring;

        /// <summary>
        /// ���
        /// </summary>
        private int _interval = 1000;

        /// <summary>
        /// ȫ�ֵ�����ȡ������
        /// </summary>
        private CancellationTokenSource globalToken = new CancellationTokenSource();

        /// <summary>
        /// �ؼ�
        /// </summary>
        public WpfPlot ChartControl
        {
            get => chartControl;
            set => SetProperty(ref chartControl, value);
        }
        private WpfPlot chartControl = new WpfPlot();

        /// <summary>
        /// ��Ϣ�¼�
        /// </summary>
        public string Info
        {
            get => GetProperty(() => Info);
            set => SetProperty(() => Info, value);
        }

        /// <summary>
        /// �豸����
        /// </summary>
        public ObservableCollection<ConsoleDevice> Devices
        {
            get => _Devices;
            set => SetProperty(ref _Devices, value);
        }
        private ObservableCollection<ConsoleDevice> _Devices = new ObservableCollection<ConsoleDevice>();
        #endregion

        #region �����뷽��
        /// <summary>
        /// �������
        /// </summary>
        public IAsyncRelayCommand Clear => p_Clear ??= new AsyncRelayCommand(ClearAsync);
        IAsyncRelayCommand p_Clear;
        /// <summary>
        /// �����Ϣ
        /// </summary>
        /// <returns></returns>
        public async Task ClearAsync()
        {
            await uiMessage.ClearAsync();
        }

        /// <summary>
        /// Mqtt���������޸�
        /// </summary>
        public IAsyncRelayCommand MqttServerUpdate => p_MqttServerUpdate ??= new AsyncRelayCommand(MqttServerUpdateAsync);
        IAsyncRelayCommand p_MqttServerUpdate;
        public async Task MqttServerUpdateAsync()
        {
            if (File.Exists(GlobalConfigModel.MqttServerConfigPath))
            {
                MqttServiceData.Basics? basics = FileHandler.FileToString(GlobalConfigModel.MqttServerConfigPath).ToJsonEntity<MqttServiceData.Basics>();
                GlobalConfigModel.param.SetBasics(basics);
                if ((await DialogHost.Show(GlobalConfigModel.param, GlobalConfigModel.DialogHostTag)).ToBool())
                {
                    basics = GlobalConfigModel.param.GetBasics().GetSource<MqttServiceData.Basics>();
                    //д������
                    FileHandler.StringToFile(GlobalConfigModel.MqttServerConfigPath, basics.ToJson(true));
                }
            }
        }

        /// <summary>
        /// ����Mqtt����
        /// </summary>
        public IAsyncRelayCommand MqttServerStart => p_MqttServerStart ??= new AsyncRelayCommand(MqttServerStartAsync);
        IAsyncRelayCommand p_MqttServerStart;
        public async Task MqttServerStartAsync()
        {
            if (GlobalConfigModel.mqttService is null)
            {
                GlobalConfigModel.param.SetBasics(new MqttServiceData.Basics());
                if ((await DialogHost.Show(GlobalConfigModel.param, GlobalConfigModel.DialogHostTag)).ToBool())
                {
                    MqttServiceData.Basics basics = GlobalConfigModel.param.GetBasics().GetSource<MqttServiceData.Basics>();
                    GlobalConfigModel.mqttService = await MqttServiceOperate.InstanceAsync(basics);
                    //������������
                    if (!Directory.Exists(GlobalConfigModel.ServerConfigPath))
                    {
                        Directory.CreateDirectory(GlobalConfigModel.ServerConfigPath);
                    }
                    FileHandler.StringToFile(GlobalConfigModel.MqttServerConfigPath, basics.ToJson(true));

                    await MqttServerInitAsync();
                    await RefreshAsync();
                }
            }
            else
            {
                await MessageBox.Show("������".GetLanguageValue(App.LanguageOperate), "Mqtt");
            }
        }

        /// <summary>
        /// Mqtt����˳�ʼ��
        /// </summary>
        /// <returns></returns>
        private async Task MqttServerInitAsync()
        {
            if (File.Exists(GlobalConfigModel.MqttServerConfigPath))
            {
                //ʵ��������
                MqttServiceData.Basics? basics = FileHandler.FileToString(GlobalConfigModel.MqttServerConfigPath).ToJsonEntity<MqttServiceData.Basics>();
                //ʵ����
                GlobalConfigModel.mqttService = MqttServiceOperate.Instance(basics ??= new());
            }

            if (GlobalConfigModel.mqttService is not null)
            {
                GlobalConfigModel.mqttService.OnInfoEventAsync += MqttService_OnInfoEventAsync;
                OperateResult result = await GlobalConfigModel.mqttService.OnAsync();
                await ShowAsync(result.ToJson(true));
                if (!result.Status)
                {
                    GlobalConfigModel.mqttService.OnInfoEventAsync -= MqttService_OnInfoEventAsync;
                    await GlobalConfigModel.mqttService.DisposeAsync();
                    GlobalConfigModel.mqttService = null;
                }
            }
        }

        private async Task MqttService_OnInfoEventAsync(object? sender, EventInfoResult e)
        {
            await ShowAsync($"[ MqttService ] {e.Status.ToString().ToUpperInvariant()}\r\n{e.ToJson(true)}");
        }

        /// <summary>
        /// ֹͣMqtt����
        /// </summary>
        public IAsyncRelayCommand MqttServerStop => p_MqttServerStop ??= new AsyncRelayCommand(MqttServerStopAsync);
        IAsyncRelayCommand p_MqttServerStop;
        public async Task MqttServerStopAsync()
        {
            if (GlobalConfigModel.mqttService is not null)
            {
                OperateResult result = await GlobalConfigModel.mqttService.OffAsync();
                await ShowAsync(result.ToJson(true));
                GlobalConfigModel.mqttService.OnInfoEventAsync -= MqttService_OnInfoEventAsync;
                await GlobalConfigModel.mqttService.DisposeAsync();
                GlobalConfigModel.mqttService = null;
                await RefreshAsync();
            }
            else
            {
                await MessageBox.Show("δ����".GetLanguageValue(App.LanguageOperate), "Mqtt");
            }
        }

        /// <summary>
        /// OPCUA���������޸�
        /// </summary>
        public IAsyncRelayCommand OpcUaServerUpdate => p_OpcUaServerUpdate ??= new AsyncRelayCommand(OpcUaServerUpdateAsync);
        IAsyncRelayCommand p_OpcUaServerUpdate;
        public async Task OpcUaServerUpdateAsync()
        {
            if (File.Exists(GlobalConfigModel.UaServerConfigPath))
            {
                OpcUaServiceData.Basics? basics = FileHandler.FileToString(GlobalConfigModel.UaServerConfigPath).ToJsonEntity<OpcUaServiceData.Basics>();
                GlobalConfigModel.param.SetBasics(basics);
                if ((await DialogHost.Show(GlobalConfigModel.param, GlobalConfigModel.DialogHostTag)).ToBool())
                {
                    basics = GlobalConfigModel.param.GetBasics().GetSource<OpcUaServiceData.Basics>();
                    //д������
                    FileHandler.StringToFile(GlobalConfigModel.UaServerConfigPath, basics.ToJson(true));
                }
            }
        }

        /// <summary>
        /// ����OPCUA����
        /// </summary>
        public IAsyncRelayCommand OpcUaServerStart => p_OpcUaServerStart ??= new AsyncRelayCommand(OpcUaServerStartAsync);
        IAsyncRelayCommand p_OpcUaServerStart;
        public async Task OpcUaServerStartAsync()
        {
            if (GlobalConfigModel.uaService is null)
            {
                GlobalConfigModel.param.SetBasics(new OpcUaServiceData.Basics());
                if ((await DialogHost.Show(GlobalConfigModel.param, GlobalConfigModel.DialogHostTag)).ToBool())
                {
                    OpcUaServiceData.Basics basics = GlobalConfigModel.param.GetBasics().GetSource<OpcUaServiceData.Basics>();
                    GlobalConfigModel.uaService = await OpcUaServiceOperate.InstanceAsync(basics);
                    //������������
                    if (!Directory.Exists(GlobalConfigModel.ServerConfigPath))
                    {
                        Directory.CreateDirectory(GlobalConfigModel.ServerConfigPath);
                    }
                    FileHandler.StringToFile(GlobalConfigModel.UaServerConfigPath, basics.ToJson(true));

                    await OpcUaServerInitAsync();
                    await RefreshAsync();
                }
            }
            else
            {
                await MessageBox.Show("������".GetLanguageValue(App.LanguageOperate), "OpcUa");
            }
        }

        /// <summary>
        /// OPCUA����˳�ʼ��
        /// </summary>
        /// <returns></returns>
        private async Task OpcUaServerInitAsync()
        {
            if (File.Exists(GlobalConfigModel.UaServerConfigPath))
            {
                //ʵ��������
                OpcUaServiceData.Basics? basics = FileHandler.FileToString(GlobalConfigModel.UaServerConfigPath).ToJsonEntity<OpcUaServiceData.Basics>();
                //ʵ����
                GlobalConfigModel.uaService = OpcUaServiceOperate.Instance(basics ??= new());
            }

            if (GlobalConfigModel.uaService is not null)
            {
                GlobalConfigModel.uaService.OnInfoEventAsync += UaService_OnInfoEventAsync;
                OperateResult result = await GlobalConfigModel.uaService.OnAsync();
                await ShowAsync(result.ToJson(true));
                if (!result.Status)
                {
                    GlobalConfigModel.uaService.OnInfoEventAsync -= UaService_OnInfoEventAsync;
                    await GlobalConfigModel.uaService.DisposeAsync();
                    GlobalConfigModel.uaService = null;
                }
            }
        }

        private async Task UaService_OnInfoEventAsync(object? sender, EventInfoResult e)
        {
            await ShowAsync($"[ OpcUaService ] {e.Status.ToString().ToUpperInvariant()}\r\n{e.ToJson(true)}");
        }

        /// <summary>
        /// ֹͣOPCUA����
        /// </summary>
        public IAsyncRelayCommand OpcUaServerStop => p_OpcUaServerStop ??= new AsyncRelayCommand(OpcUaServerStopAsync);
        IAsyncRelayCommand p_OpcUaServerStop;
        public async Task OpcUaServerStopAsync()
        {
            if (GlobalConfigModel.uaService is not null)
            {
                OperateResult result = await GlobalConfigModel.uaService.OffAsync();
                await ShowAsync(result.ToJson(true));
                GlobalConfigModel.uaService.OnInfoEventAsync -= UaService_OnInfoEventAsync;
                await GlobalConfigModel.uaService.DisposeAsync();
                GlobalConfigModel.uaService = null;
                await RefreshAsync();
            }
            else
            {
                await MessageBox.Show("δ����".GetLanguageValue(App.LanguageOperate), "OpcUa");
            }
        }

        /// <summary>
        /// ˢ��
        /// </summary>
        public IAsyncRelayCommand Refresh => refresh ??= new AsyncRelayCommand(GlobalConfigModel.RefreshAsyncFunc ??= RefreshAsync);
        private IAsyncRelayCommand refresh;
        public async Task RefreshAsync()
        {
            List<IProjectTreeViewModel> devices = GlobalConfigModel.ProjectDict.GetAllDeviceNodes();
            await ShowAsync(devices.Count + " " + "̨�豸�ѳɹ�����".GetLanguageValue(App.LanguageOperate));
            await SyncDevicesAsync(devices, Devices, ResultAsync, ShowAsync);
        }

        /// <summary>
        /// ͬ���豸���ϣ����򴴽� / ���� + �����Ƴ���
        /// </summary>
        /// <param name="sourceDevices">��Ŀ���е��豸�ڵ�</param>
        /// <param name="uiDevices">UI ��ʾ���豸����</param>
        /// <param name="resultAsync">����ص�</param>
        /// <param name="showAsync">��ʾ�ص�</param>
        private async Task SyncDevicesAsync(
            List<IProjectTreeViewModel> sourceDevices,
            ObservableCollection<ConsoleDevice> uiDevices,
            Func<PluginConfigModel, BaseModel, Task> resultAsync,
            Func<string, Task> showAsync)
        {
            if (sourceDevices == null || uiDevices == null)
                return;

            //���� guid �� device ���������� O(n2) ����
            var deviceMap = new Dictionary<string, ConsoleDevice>(uiDevices.Count);
            foreach (var d in uiDevices)
                deviceMap[d.DataContext.GetSource<ConsoleDeviceModel>().ToString()] = d;

            //����ͬ�������� / ����
            foreach (var item in sourceDevices)
            {
                string guid = item.DaqDetails.Guid;

                if (!deviceMap.TryGetValue(guid, out var existedDevice))
                {
                    // �½��豸
                    ConsoleDevice device = new ConsoleDevice();
                    ConsoleDeviceModel model = device.DataContext.GetSource<ConsoleDeviceModel>();

                    await model.SettingsAsync(item, resultAsync, showAsync);
                    uiDevices.Add(device);
                }
                else
                {
                    // ���������豸
                    await existedDevice.DataContext.GetSource<ConsoleDeviceModel>().SettingsAsync(item, resultAsync, showAsync);
                }
            }
            //����ͬ�����Ƴ������ڵ��豸
            var validGuidSet = sourceDevices
                .Select(d => d.DaqDetails.Guid)
                .ToHashSet();

            var removeList = uiDevices
                .Where(d =>
                {
                    var model = d.DataContext.GetSource<ConsoleDeviceModel>();
                    return !validGuidSet.Contains(model.ToString());
                })
                .ToList();

            foreach (var device in removeList)
            {
                await device.DataContext.GetSource<ConsoleDeviceModel>().DisposeAsync();
                uiDevices.Remove(device);
            }

            // ͬ�������豸״̬���ϣ���ϵͳ�����Ҽ��˵�ʹ��
            GlobalConfigModel.TrayDevices.Clear();
            foreach (var device in uiDevices)
            {
                GlobalConfigModel.TrayDevices.Add(device.DataContext.GetSource<ConsoleDeviceModel>());
            }
        }


        /// <summary>
        /// �豸�����Ϣ
        /// </summary>
        /// <param name="result">���</param>
        private async Task ResultAsync(PluginConfigModel model, BaseModel result)
        {
            if (!result.Status)
            {
                string msg = $"[ Error ] {result.Time} : [ {model.Type} ] {result.Message}";
                await uiMessage.ShowAsync(msg, withTime: false);
                LogHelper.Error(msg, foldername: "msg");
            }
        }

        /// <summary>
        /// ������ʾ��Ϣ
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private async Task ShowAsync(string message)
        {
            string msg = $"[ Info ] {DateTime.Now} : {message}";
            await uiMessage.ShowAsync(msg, withTime: false);
            LogHelper.Info(msg, foldername: "msg");
        }


        /// <summary>
        /// ��ʼ��
        /// </summary>
        /// <returns></returns>
        private async Task InitAsync()
        {
            // ������Ϣ����
            uiMessage.OnInfoEventAsync += async (object? sender, Model.data.EventInfoResult e) => Info = e.Message;
            await uiMessage.StartAsync();

            // ͼ������
            chartOperate = ChartOperate.Instance(new()
            {
                ChartControl = ChartControl,
                LineAdjust = true,
                HideGrid = true,
                RefreshTime = _interval
            });
            chartOperate.On();
            chartOperate.Create(new() { SN = "Cpu", Title = "������", TitleEN = "Cpu", Color = "#4CAF50" });
            chartOperate.Create(new() { SN = "Gpu", Title = "�Կ�", TitleEN = "Gpu", Color = "#F44336" });
            chartOperate.Create(new() { SN = "RAM", Title = "�ڴ�", TitleEN = "RAM", Color = "#2196F3" });

            // ϵͳ���
            systemMonitoring = SystemMonitoring.Instance();

            // ����ϵͳ���ֵ
            _ = UpdateSystemMonitoringValueAsync(globalToken.Token).ConfigureAwait(false);

            //OPCUA���������
            await OpcUaServerInitAsync();

            //Mqtt���������
            await MqttServerInitAsync();

            //��ֵ�����Ϣ
            GlobalConfigModel.RefreshAsyncFunc = RefreshAsync;

            //ˢ��
            await RefreshAsync();
        }
        #endregion
    }
}
