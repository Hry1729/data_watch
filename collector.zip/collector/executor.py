"""
任务执行器模块

本模块提供采集任务的执行功能：
- TaskExecutor: 执行具体的采集操作
- 调用驱动读取 PLC 数据
- 解析结果并生成 DataPoint 入队

典型用法:
    executor = TaskExecutor(buffer, device_manager)
    await executor.execute(task)
"""

import time
import traceback
from datetime import datetime
import struct
from typing import Any, Dict, List, Optional

from core.exceptions import ReadError
from core.logger import get_logger
from collector.task import CollectTask
from data_queue.buffer import DataBuffer, DataPoint
from device.manager import DeviceManager

logger = get_logger("executor")

# 相同日志抑制间隔（秒）
LOG_SUPPRESS_INTERVAL = 30


class TaskExecutor:
    """
    任务执行器
    执行具体的采集操作：调用驱动读取，将结果放入队列
    """

    def __init__(
        self,
        buffer: DataBuffer,
        device_manager: Optional[DeviceManager] = None,
        system_logger: Optional[Any] = None,
        summary_interval_seconds: float = 60.0,
    ):
        self.buffer = buffer
        self.device_manager = device_manager
        self._system_logger = system_logger
        self._summary_interval_seconds = summary_interval_seconds
        self._summary_started_at = time.time()
        self._summary_tasks = 0
        self._summary_points = 0
        self._summary_errors = 0
        self._summary_elapsed_ms = 0.0
        self._total_reads = 0
        self._total_errors = 0
        self._total_dropped = 0  # 队列满时丢弃的点数
        # 日志抑制：记录每个设备上次 "not connected" 警告的时间
        self._device_warn_last_time: Dict[str, float] = {}

    async def execute(self, task: CollectTask) -> None:
        """
        执行单个采集任务
        1. 调用驱动批量读取
        2. 解析结果
        3. 生成DataPoint入队
        """
        device = task.device
        scan_task = task.scan_task

        if not device.driver or not device.driver.is_connected:
            # 日志抑制：同一设备在 LOG_SUPPRESS_INTERVAL 秒内只输出一次警告
            now = time.time()
            last_warn = self._device_warn_last_time.get(device.device_id, 0)
            if now - last_warn >= LOG_SUPPRESS_INTERVAL:
                logger.warning(
                    "Device %s not connected, skipping task %s",
                    device.device_id,
                    task.task_name,
                )
                self._device_warn_last_time[device.device_id] = now
            if self.device_manager:
                await self.device_manager.schedule_reconnect(device)
            return

        # 批量读取
        start = time.time()
        try:
            result = await device.driver.read(scan_task.read_blocks)
            if scan_task.read_blocks and all(result.get(block.address) is None for block in scan_task.read_blocks):
                raise ReadError(f"All read blocks failed for task {task.task_name}")
            elapsed = time.time() - start
            self._total_reads += 1

            # 解析结果并入队
            points = self._parse_result(device.device_id, scan_task, result)
            if points:
                accepted = await self.buffer.put_batch(points)
                dropped = len(points) - accepted
                if dropped > 0:
                    logger.warning(
                        "Task %s: queue full, dropped %d/%d points",
                        task.task_name,
                        dropped,
                        len(points),
                    )
                    self._total_dropped += dropped

            logger.debug(
                "Task %s: read %s points in %.1fms",
                task.task_name,
                len(points),
                elapsed * 1000,
            )
            self._record_read_summary(task, len(points), elapsed * 1000)

        except Exception as e:
            self._total_errors += 1
            logger.error("Task %s read failed: %s", task.task_name, e)
            elapsed_ms = (time.time() - start) * 1000
            self._emit_read_failure(task, e, elapsed_ms)
            self._record_read_summary(task, 0, elapsed_ms, error=True)
            if self.device_manager:
                await self.device_manager.mark_device_error(device, f"read failed: {e}", "timeout")
            raise

    def _parse_result(
        self,
        device_id: str,
        scan_task,
        result: dict,
    ) -> List[DataPoint]:
        """解析读取结果为DataPoint列表"""
        points = []
        now = datetime.now()

        for variable in scan_task.variables:
            # 仅将需要入库的变量送入队列，减轻聚合与存储压力
            if not variable.is_storage:
                continue

            result_map = getattr(scan_task, "result_map", {})
            mapped = result_map.get(variable.variable_id)
            if mapped:
                block_addr = mapped["block_address"]
                raw_values = result.get(block_addr)
                if raw_values is None:
                    continue

                # 根据 protocol 选择还原方法
                protocol = mapped.get("protocol", "")
                if protocol == "ge_srtp":
                    value = self._extract_mapped_ge_value(raw_values, mapped)
                else:
                    value = self._extract_mapped_s7_value(raw_values, mapped)

                points.append(DataPoint(
                    device_id=device_id,
                    variable_id=variable.variable_id,
                    value=value,
                    timestamp=now,
                ))
                continue

            block_addr = variable.address
            raw_values = result.get(block_addr)

            if raw_values is None:
                continue

            # 单值或多值
            values = raw_values if isinstance(raw_values, list) else [raw_values]

            for val in values:
                point = DataPoint(
                    device_id=device_id,
                    variable_id=variable.variable_id,
                    value=val,
                    timestamp=now,
                )
                points.append(point)

        return points

    @staticmethod
    def _extract_mapped_s7_value(raw_values: Any, mapping: Dict[str, Any]) -> Any:
        """从合并后的 S7 I/Q/M BYTE 块或 Timer/Counter 块中还原单个变量值。"""
        values = raw_values if isinstance(raw_values, list) else [raw_values]
        if "value_offset" in mapping:
            return values[int(mapping.get("value_offset", 0))]

        raw = bytearray(int(value) & 0xFF for value in values)
        offset = int(mapping.get("byte_offset", 0))
        bit = mapping.get("bit")
        data_type = str(mapping.get("data_type", "BYTE")).upper()

        if bit is not None:
            return bool((raw[offset] >> int(bit)) & 1)
        if data_type == "BYTE":
            return raw[offset]
        if data_type == "INT":
            return struct.unpack(">h", raw[offset:offset + 2])[0]
        if data_type == "WORD":
            return struct.unpack(">H", raw[offset:offset + 2])[0]
        if data_type in {"REAL", "FLOAT"}:
            return struct.unpack(">f", raw[offset:offset + 4])[0]
        if data_type == "DINT":
            return struct.unpack(">i", raw[offset:offset + 4])[0]
        if data_type == "DWORD":
            return struct.unpack(">I", raw[offset:offset + 4])[0]
        return raw[offset]

    @staticmethod
    def _extract_mapped_ge_value(raw_values: Any, mapping: Dict[str, Any]) -> Any:
        """
        从合并后的 GE 块中还原单个变量值。

        寄存器区域 (%R/%AI/%AQ):
            word_offset 定位起始 word
            INT: 有符号 16 位
            WORD/UINT: 无符号 16 位
            DINT: 2 word 组合为有符号 32 位
            DWORD/UDINT: 2 word 组合为无符号 32 位
            REAL/FLOAT: 2 word 组合为 32 位浮点

        离散量区域 (%I/%Q/%M):
            第一版只支持 BOOL
            bit_offset 直接从 bit list 中取值

        REAL/DINT/DWORD 字序：
            当前只支持 word_order="low_high"（低地址 word 在前，高地址 word 在后）
            与 GE PACSystems 文档和 gesrtp-py 实现一致，但仍需现场已知值校验后固化
        """
        values = raw_values if isinstance(raw_values, list) else [raw_values]
        area = str(mapping.get("area", ""))
        data_type = str(mapping.get("data_type", "INT")).upper()

        # 寄存器区域：word 偏移
        if area in ("R", "AI", "AQ"):
            word_offset = int(mapping.get("word_offset", 0))
            word_length = int(mapping.get("word_length", 1))
            # 获取 word_order 配置（当前只支持 low_high）
            word_order = str(mapping.get("word_order", "low_high"))

            # 单 word 类型
            if data_type == "INT":
                # 有符号 16 位：gesrtp-py 已用 <h 返回 signed，只需处理 unsigned 输入
                val = int(values[word_offset])
                if val > 0x7FFF:
                    return val - 0x10000  # unsigned 转 signed
                return val
            if data_type in ("WORD", "UINT"):
                return values[word_offset] & 0xFFFF
            if data_type == "USINT":
                return values[word_offset] & 0xFF

            # 2 word 类型：组合为 32 位值
            if word_length >= 2 and word_offset + 1 < len(values):
                if word_order != "low_high":
                    raise ValueError(f"Unsupported GE word_order: {word_order}. Current only supports low_high.")

                low = values[word_offset] & 0xFFFF
                high = values[word_offset + 1] & 0xFFFF

                if data_type in ("DINT",):
                    # 有符号 32 位（low_high word 序：low + high << 16）
                    val = low | (high << 16)
                    if val >= 0x80000000:
                        val -= 0x100000000
                    return val
                if data_type in ("DWORD", "UDINT"):
                    return low | (high << 16)
                if data_type in ("REAL", "FLOAT"):
                    # IEEE 754 浮点（low_high word 序）
                    raw_bytes = struct.pack('<HH', low, high)
                    return struct.unpack('<f', raw_bytes)[0]

            return values[word_offset]

        # 离散量区域：BOOL bit 偏移
        if area in ("I", "Q", "M"):
            if data_type == "BOOL":
                bit_offset = int(mapping.get("bit_offset", 0))
                return bool(values[bit_offset])
            # 第一版不支持离散区的多字节类型
            logger.warning(
                "GE discrete area %s does not support %s in this version",
                area, data_type
            )
            return None

        return values[0]

    def _emit_read_failure(self, task: CollectTask, error: Exception, elapsed_ms: float) -> None:
        """Record a failed read as a system log without blocking collection."""
        if self._system_logger is None:
            return

        device = task.device
        self._system_logger.emit(
            level="ERROR",
            log_type="collect",
            source="collector.executor",
            device_id=getattr(device, "device_pk", None),
            device_code=device.device_id,
            content=f"Collect task {task.task_name} read failed",
            detail_json={
                "task_name": task.task_name,
                "scan_rate": getattr(task.scan_task, "scan_rate", None),
                "read_blocks": [
                    getattr(block, "address", str(block))
                    for block in getattr(task.scan_task, "read_blocks", [])
                ],
                "error": str(error),
            },
            exception_stack="".join(
                traceback.format_exception(type(error), error, error.__traceback__)
            )[:4000],
            elapsed_ms=int(elapsed_ms),
        )

    def _record_read_summary(
        self,
        task: CollectTask,
        points_count: int,
        elapsed_ms: float,
        error: bool = False,
    ) -> None:
        """Emit one compact collection summary per interval instead of per point."""
        if self._system_logger is None:
            return

        self._summary_tasks += 1
        self._summary_points += points_count
        self._summary_elapsed_ms += elapsed_ms
        if error:
            self._summary_errors += 1

        now = time.time()
        if now - self._summary_started_at < self._summary_interval_seconds:
            return

        interval_seconds = max(0.001, now - self._summary_started_at)
        average_elapsed_ms = (
            self._summary_elapsed_ms / self._summary_tasks
            if self._summary_tasks
            else 0
        )
        level = "WARN" if self._summary_errors else "INFO"
        self._system_logger.emit(
            level=level,
            log_type="collect",
            source="collector.executor",
            content="Collector read summary",
            detail_json={
                "interval_seconds": round(interval_seconds, 3),
                "tasks": self._summary_tasks,
                "points": self._summary_points,
                "errors": self._summary_errors,
                "average_elapsed_ms": round(average_elapsed_ms, 3),
                "last_task": task.task_name,
                "last_device_code": task.device.device_id,
                "total_reads": self._total_reads,
                "total_errors": self._total_errors,
            },
        )

        self._summary_started_at = now
        self._summary_tasks = 0
        self._summary_points = 0
        self._summary_errors = 0
        self._summary_elapsed_ms = 0.0

    @property
    def stats(self):
        return {
            "total_reads": self._total_reads,
            "total_errors": self._total_errors,
            "total_dropped": self._total_dropped,
        }
